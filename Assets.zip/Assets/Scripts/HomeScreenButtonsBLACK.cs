using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtonsBLACK : MonoBehaviour
{
    
    public AudioClip PlayButton;
    private AudioSource audioSource;
    public void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = PlayButton;
    }
    public void loadHomePageBLACK()
    {
        audioSource.Play();
        StartCoroutine(WaitloadHomePageBLACK()); 
        //SceneManager.LoadScene("HomeBLACK");
    }
    public void PlayButtonBLACK()
    {
        audioSource.Play();
        StartCoroutine(WaitPlayButtonBLACK()); 
        //SceneManager.LoadScene("SampleSceneBLACK");
    }
    public void loadShoppingPageBLACK()
    {
        audioSource.Play();
        StartCoroutine(WaitloadShoppingPageBLACK()); 
        //SceneManager.LoadScene("ShoppingBLACK");
    }


    private IEnumerator WaitloadHomePageBLACK()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("HomeBLACK");
    }
    private IEnumerator WaitPlayButtonBLACK()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("SampleSceneBLACK");
    }
    private IEnumerator WaitloadShoppingPageBLACK()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("ShoppingBLACK");
    }
   
    public void ThemeBLACK()
    {
        SceneManager.LoadScene("THEMESELECTION");
    }



    
    
}
