using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtonsBLACK : MonoBehaviour
{
    
    public void loadHomePageBLACK()
    {
        SceneManager.LoadScene("HomeBLACK");
    }
    public void PlayButtonBLACK()
    {
        SceneManager.LoadScene("SampleSceneBLACK");
    }
    public void loadShoppingPageBLACK()
    {
        SceneManager.LoadScene("ShoppingBLACK");
    }


    public void ThemeBLACK()
    {
        SceneManager.LoadScene("THEMESELECTION");
    }
}
