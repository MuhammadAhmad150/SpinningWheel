using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtonsCOLOUR : MonoBehaviour
{
    public void loadHomePage()
    {
        SceneManager.LoadScene("HomeCOLOUR");
    }

    public void PlayButton()
    {
        SceneManager.LoadScene("SampleSceneCOLOUR");
    }

    public void loadShoppingPage()
    {
        SceneManager.LoadScene("ShoppingCOLOUR");
    }

    public void ThemeCOLOUR()
    {
        SceneManager.LoadScene("THEMESELECTION");
    }
}
