using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtonsWHITE : MonoBehaviour
{
    public AudioClip PlayButton;
    private AudioSource audioSource;
    public void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = PlayButton;
    }
    public void loadHomePageWHITE()
    {
        audioSource.Play();
        StartCoroutine(WaitloadHomePageWHITE()); 
        //SceneManager.LoadScene("HomeWHITE");
    }

    public void PlayButtonWHITE()
    {
        audioSource.Play();
        StartCoroutine(WaitPlayButtonWHITE()); 
        //SceneManager.LoadScene("SampleSceneWHITE");
    }
    public void loadShoppingPageWHITE()
    {
        audioSource.Play();
        StartCoroutine(WaitloadShoppingPageWHITE()); 
        //SceneManager.LoadScene("ShoppingWHITE");
    }


    private IEnumerator WaitloadHomePageWHITE()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("HomeWHITE");
    }
    private IEnumerator WaitPlayButtonWHITE()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("SampleSceneWHITE");
    }
    private IEnumerator WaitloadShoppingPageWHITE()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("ShoppingWHITE");
    }
    public void ThemeWHITE()
    {
        SceneManager.LoadScene("THEMESELECTION");
    }
}
