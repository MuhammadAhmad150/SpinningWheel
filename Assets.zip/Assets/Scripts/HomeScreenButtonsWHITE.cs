using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtonsWHITE : MonoBehaviour
{
    public void loadHomePageWHITE()
    {
        SceneManager.LoadScene("HomeWHITE");
    }

    public void PlayButtonWHITE()
    {
        SceneManager.LoadScene("SampleSceneWHITE");
    }

    public void loadShoppingPageWHITE()
    {
        SceneManager.LoadScene("ShoppingWHITE");
    }

    public void ThemeWHITE()
    {
        SceneManager.LoadScene("THEMESELECTION");
    }
}
