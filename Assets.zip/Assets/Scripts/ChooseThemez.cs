using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChooseThemez : MonoBehaviour
{
    public void WHITETHEME()
    {
        SceneManager.LoadScene("HomeWHITE");
    }

    public void BLACKTHEME()
    {
        SceneManager.LoadScene("HomeBLACK");
    }

    public void COLOURTHEME()
    {
        SceneManager.LoadScene("HomeCOLOUR");
    }
}

