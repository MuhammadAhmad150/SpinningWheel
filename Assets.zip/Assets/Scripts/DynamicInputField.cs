using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class DynamicInputField : MonoBehaviour
{
    public GameObject canvas;
    public GameObject inputFieldPrefab; // Assign the Input Field prefab in the Unity Inspector.
    private float yaxis = 0f;
    private List<string> stringList = new List<string>();
    private int index = 1; // Initialize the index to 1 or any other starting value you prefer.

public void Start()
{
    for(int i=0;i<5;i++)
    {
        AddName();
    }
}
    public void AddName()
    {
        GameObject instantiatedInputField = Instantiate(inputFieldPrefab, canvas.transform);
        RectTransform rectTransform = instantiatedInputField.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(0f, yaxis, 0f);
        rectTransform.localRotation = Quaternion.identity;

        InputField inputField = instantiatedInputField.GetComponent<InputField>();
        inputField.onEndEdit.AddListener(OnInputFieldEndEdit);

        yaxis -= 95f;
    }

    private void OnInputFieldEndEdit(string inputText)
    {
        stringList.Add(inputText + "-" + index.ToString());
        index++;
        Debug.Log("Entered Text: " + inputText);
        populateLIST();
    }

    private void populateLIST()
    {
        foreach (string element in stringList)
        {
            Debug.Log(element);
        }
    }
}
