using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


[System.Serializable]
public class NameData1COLOUR
{
    public string[] names;
}

public class ReaderSampleSceneCOLOUR : MonoBehaviour
{
   
    public AudioClip AddaudioClip;
    private AudioSource audioSourceAdd;

    public CircleDivisionCOLOUR circularDivision;
    public int index=1;
    public Canvas canvas;
    public GameObject panel;
    public float yaxis=33f;
    public GameObject inputFieldPrefab;
    public List<string> stringList1 = new List<string>();
    
    public GameObject textContainer;
    public void Start()
    { 
        ScrollRect scrollRect = textContainer.GetComponent<ScrollRect>();
        scrollRect.vertical = false;

        audioSourceAdd = gameObject.AddComponent<AudioSource>();
        audioSourceAdd.clip = AddaudioClip;

        stringList1.Clear();
        GameObject circularObject = GameObject.Find("GameObject");
        circularDivision = circularObject.GetComponent<CircleDivisionCOLOUR>();
        //circularDivision.CreateCircularSegment(0f,359.85f,"red",50f,"");
        //circularDivision.CreateCircularSegment(359.85f,360f,"white",50f,"");
        circularDivision.CreateCircularSegment(1f,0f,90f,"red",50f,"");
        circularDivision.CreateCircularSegment(1f,90f,180f,"red",141f,"");
        circularDivision.CreateCircularSegment(1f,180f,270f,"blue",221f,"");
        circularDivision.CreateCircularSegment(1f,270f,360f,"blue",313f,"");
        circularDivision.CreateHollowCircle();
        circularDivision.CreateCircularSegment1(0f,360f,"red",313f,"");
    }
    public void Update()
    {  
       
        if(circularDivision.spinButtonPressed==false)
        {
            //Refresh();
        }
    }
   public void writeToJSON()
    {
        string filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, string.Empty);

        NameData1COLOUR NameData11 = new NameData1COLOUR();
        NameData11.names = stringList1.ToArray();
        string jsonString = JsonUtility.ToJson(NameData11);
        System.IO.File.WriteAllText(filePath, jsonString);
    }

    public void addName()   
    {
        audioSourceAdd.Play();
        GameObject instantiatedInputField = Instantiate(inputFieldPrefab, panel.transform);
        RectTransform rectTransform = instantiatedInputField.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(0f, yaxis, 0f);
        rectTransform.localRotation = Quaternion.identity;

        InputField inputField = instantiatedInputField.GetComponent<InputField>();
        inputField.onEndEdit.AddListener(OnInputFieldEndEdit);
        //  Invoke("SetFocusOnTextField", 0.1f);
        inputField.Select();
        inputField.ActivateInputField();

        yaxis -= 65f;
        string textValue = inputField.text;
     }
    private void OnInputFieldEndEdit(string inputText)
    {
        if (!string.IsNullOrWhiteSpace(inputText))
        {
            stringList1.Add(inputText);
            index++;
        }
        Refresh();
    }
    public void Refresh()
    {
        stringList1.Clear();
        GameObject[] taggedObjects = GameObject.FindGameObjectsWithTag("Name");
        Debug.Log("Resfresh="+taggedObjects.Length);
        if(taggedObjects.Length>=8)
        {
            ScrollRect scrollRect = textContainer.GetComponent<ScrollRect>();
            scrollRect.vertical = true;
        }
        foreach (GameObject obj in taggedObjects)
        {
            InputField textComponent = obj.GetComponent<InputField>();
            string fullText = textComponent.text;
          
            int textLength = fullText.Length;
            if(textLength>=1)
            {
                if(textLength>8)
                {
                    fullText=fullText.Substring(0,8);
                    fullText+="...";
                    stringList1.Add(fullText);
                    //textComponent.text = textComponent.text.Substring(0, 8);
                    //textComponent.text+=".";
                }
                else
                    stringList1.Add(textComponent.text);
            }

            //if (textComponent != null)
            //{
              //  int hyphenIndex = fullText.IndexOf('.');
                //if (hyphenIndex >= 0)
                //{
                  //  string textBeforeHyphen = fullText.Substring(0, hyphenIndex);
                  //  stringList1.Add(textBeforeHyphen);
                //}
                //stringList1.Add(textComponent.text);
            //}
            //else
            //{
              //  Debug.LogWarning("GameObject with tag!");
           // }
        }
        //SceneManager.LoadScene("SampleScene");
        
        writeToJSON();
        circularDivision.ClearSegments();
        circularDivision.DestroyCreatedObjects();
        circularDivision.BeginAgain();
    }
}

