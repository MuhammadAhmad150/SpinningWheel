using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HollowCircle : MonoBehaviour
{
    public int NumberOfSegments = 30;
    public float RADIUS = 0.2f;
    public Color fillColor = Color.black;
    public Color borderColor = Color.white;
    public float boundaryThickness = 0.05f; 

    void Start()
    {
        //CreateHollowCircle();
        GameObject prefab = Resources.Load<GameObject>("POINTER");
        if (prefab != null)
        {
            Debug.Log("instantiated");
            Instantiate(prefab, transform.position, transform.rotation);
        }
        else
        {
            Debug.Log("No instanitation");
        }
    }

    private void CreateHollowCircle()
    {
        GameObject circleObject = new GameObject("CircularSegment");
        circleObject.transform.SetParent(transform);

        // Create the inner fill
        MeshFilter meshFilter = circleObject.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = circleObject.AddComponent<MeshRenderer>();
        Mesh mesh = new Mesh();

        int verticesCount = NumberOfSegments + 1;
        Vector3[] vertices = new Vector3[verticesCount];
        int[] triangles = new int[NumberOfSegments * 3];

        float angleIncrement = 360f / NumberOfSegments;
        float currentAngle = 0f;

        for (int i = 0; i < verticesCount; i++)
        {
            float x = Mathf.Sin(currentAngle * Mathf.Deg2Rad) * RADIUS;
            float y = Mathf.Cos(currentAngle * Mathf.Deg2Rad) * RADIUS;
            vertices[i] = new Vector3(x, y, 0f);

            currentAngle += angleIncrement;
        }

        for (int i = 0; i < NumberOfSegments; i++)
        {
            triangles[i * 3] = 0; // Center vertex
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;
        }

        triangles[triangles.Length - 1] = 1; // Connect the last vertex to the second vertex to close the circle

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        meshFilter.mesh = mesh;

        Material fillMaterial = new Material(Shader.Find("Sprites/Default"));
        fillMaterial.color = fillColor;
        meshRenderer.material = fillMaterial;

        // Create the boundaries using LineRenderer
        LineRenderer lineRenderer = circleObject.AddComponent<LineRenderer>();
        lineRenderer.positionCount = verticesCount;
        lineRenderer.useWorldSpace = false;
        lineRenderer.startWidth = boundaryThickness; // Adjust the boundary thickness here
        lineRenderer.endWidth = boundaryThickness; // Adjust the boundary thickness here

        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.material.color = borderColor;

        lineRenderer.loop = true;
        for (int i = 0; i < verticesCount; i++)
        {
            lineRenderer.SetPosition(i, vertices[i]);
        }
    }


}
