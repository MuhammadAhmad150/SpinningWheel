using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


[System.Serializable]
public class NameData
{
    public string[] names;
}

public class Reader : MonoBehaviour
{
    
    public int index=1;
    public Canvas canvas;
    public float yaxis=0f;
    public InputField inputField1;
        public List<string> stringList = new List<string>();
    void Start()
    {
        if(!inputField1.multiLine )
        {
            inputField1.lineType = InputField.LineType.MultiLineNewline;
            Debug.Log("The main input field is now set to allow MultiLINE lines only!");
        }
    }
    public void buttonPressed()
    {
        stringList.Clear();
        string inputText = inputField1.text;
        string[] elements = inputText.Split('\n');
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i] = elements[i].Trim();
        }
        stringList.AddRange(elements);
        //PRINTPRINTT786
        foreach (string element in stringList)
        {
            //Debug.Log("ReaderButtonPressed"+element);
        }
        //stringList to persistent
        writeToJSON();
        SceneManager.LoadScene("SampleScene");  
    }
    public void  writeToJSON()   
    {
        NameData nameData1 = new NameData();
        nameData1.names = stringList.ToArray();
        string jsonString = JsonUtility.ToJson(nameData1);
        string filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, jsonString);
    }
}

