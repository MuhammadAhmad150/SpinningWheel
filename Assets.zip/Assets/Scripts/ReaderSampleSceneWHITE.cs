using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


[System.Serializable]
public class NameData1WHITE
{
    public string[] names;
}

public class ReaderSampleSceneWHITE : MonoBehaviour
{
    public CircleDivisionWHITE circularDivision;
    public int index=1;
    // public Canvas canvas;
    public Canvas canvas;
    public float yaxis=22f;
    public GameObject inputFieldPrefab;
    public List<string> stringList1 = new List<string>();
    
    public void Start()
    {
        GameObject circularObject = GameObject.Find("GameObject");
        circularDivision = circularObject.GetComponent<CircleDivisionWHITE>();
        stringList1.Clear();
        circularDivision.CreateCircularSegment(0f,90f,"red",50f,"");
        circularDivision.CreateCircularSegment(90f,180f,"red",141f,"");
        circularDivision.CreateCircularSegment(180f,270f,"red",221f,"");
        circularDivision.CreateCircularSegment(270f,360f,"red",313f,"");
        circularDivision.CreateHollowCircle();
    }
    public void Update()
    {  
       
        if(circularDivision.spinButtonPressed==false)
        {
            //Refresh();
        }
    }
   public void writeToJSON()
    {
        string filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, string.Empty);

        NameData1WHITE NameData1WHITE1 = new NameData1WHITE();
        NameData1WHITE1.names = stringList1.ToArray();
        string jsonString = JsonUtility.ToJson(NameData1WHITE1);
        System.IO.File.WriteAllText(filePath, jsonString);
    }

    public void addName()   
    {
        GameObject instantiatedInputField = Instantiate(inputFieldPrefab, canvas.transform);
        RectTransform rectTransform = instantiatedInputField.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(0f, yaxis, 0f);
        rectTransform.localRotation = Quaternion.identity;

        InputField inputField = instantiatedInputField.GetComponent<InputField>();
        inputField.onEndEdit.AddListener(OnInputFieldEndEdit);

        yaxis -= 65f;
         string textValue = inputField.text;
         //Debug.Log("Typed Text: " + textValue);
        //writeToJSON();
     }
    private void OnInputFieldEndEdit(string inputText)
    {
        if (!string.IsNullOrWhiteSpace(inputText))
        {
            stringList1.Add(inputText);
            //populateLIST();
            //Debug.Log("Typed Text: " + inputText);
            index++;
        }
        Refresh();
    }
    public void Refresh()
    {
        stringList1.Clear();
        GameObject[] taggedObjects = GameObject.FindGameObjectsWithTag("Name");
        Debug.Log("Resfresh="+taggedObjects.Length);
        foreach (GameObject obj in taggedObjects)
        {
            InputField textComponent = obj.GetComponent<InputField>();
            string fullText = textComponent.text;
          
            if (textComponent != null)
            {
                int hyphenIndex = fullText.IndexOf('.');
                if (hyphenIndex >= 0)
                {
                    string textBeforeHyphen = fullText.Substring(0, hyphenIndex);
                    stringList1.Add(textBeforeHyphen);
                }
                //stringList1.Add(textComponent.text);
            }
            else
            {
                Debug.LogWarning("GameObject with tag!");
            }
        }
        //SceneManager.LoadScene("SampleScene");
        
        writeToJSON();
        circularDivision.ClearSegments();
        circularDivision.DestroyCreatedObjects();
        circularDivision.BeginAgain();
    }
}

