using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingsHomeWHITE : MonoBehaviour
{
    public AudioClip SettingsAudio;
    private AudioSource audioSource;

    public GameObject CanvasThemes;
    public void ThemeWhite()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = SettingsAudio;
        audioSource.Play();
        CanvasThemes.SetActive(true);
    }
}
