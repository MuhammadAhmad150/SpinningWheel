using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SettingsScript : MonoBehaviour

{   
    public GameObject ThemezCanvas; 
    public AudioClip themeButton;
    private AudioSource audioSource;
    public void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = themeButton;
    }
    public void WHITESampleScene()
    {
        audioSource.Play();
        StartCoroutine(WaitForOneSecondWHITE()); 
    }
    public void BLACKSampleScene()
    {
        audioSource.Play();
         StartCoroutine(WaitForOneSecondBLACK()); 
    }
    public void COLOURSampleScene()
    {   
        audioSource.Play();
        StartCoroutine(WaitForOneSecondCOLOUR()); 
    }
    
     private IEnumerator WaitForOneSecondWHITE()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("SampleSceneWHITE");
    }
    private IEnumerator WaitForOneSecondBLACK()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("SampleSceneBLACK");
    }
    private IEnumerator WaitForOneSecondCOLOUR()
    {
        yield return new WaitForSeconds(0.30f);
        SceneManager.LoadScene("SampleSceneCOLOUR");
    }
    public void Exit()
    {
        audioSource.Play();
        StartCoroutine(EXITPLAY()); 
        //ThemezCanvas.SetActive(false);
    }
    private IEnumerator EXITPLAY()
    {
        yield return new WaitForSeconds(0.41f);
         //audioSource.Play();
         ThemezCanvas.SetActive(false);
    }
}
