using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;


[System.Serializable]
public class Names
{
    public string[] names;
}

[System.Serializable]
public class CirclesCOLOUR
{
    public string circleName;
    public float startingAngle;
    public float endingAngle;
}

public class CircleDivisionCOLOUR : MonoBehaviour
{
    private bool isSpinAllowed;
    public GameObject Canvas;
    public GameObject CanvasPanel;
    public Text WinnerText;
    public GameObject ParticleSystem;
    public float maxRotationSpeed = 510f; // Maximum rotation 
    public float rotationDeceleration = 90f; // Deceleration 
    public float totalAngleRotated = 0f;

    List<string> updatedNames = new List<string>{};
    List<CirclesCOLOUR> circlesList = new List<CirclesCOLOUR>();

    public int numSegments = 100;      
    public float radius = 2.5f;         
    

    public int NumberOfSegments = 30;
    public float RADIUS = 0.5f;
    public Color fillColor = new Color32(207, 207, 207, 255);
    public Color borderColor = Color.white;
    public float boundaryThickness = 0.079f; 

    public bool spinButtonPressed=false; 

    public void BeginAgain()
    { 
        isSpinAllowed=true;
        maxRotationSpeed = UnityEngine.Random.Range(1095f, 1995f);
        string filePath = Application.persistentDataPath + "/names.json";
        Names deserializedNameData=null;
        
        if (File.Exists(filePath))
        {
            string jsonString = File.ReadAllText(filePath);

            deserializedNameData = JsonUtility.FromJson<Names>(jsonString);

            float angleSize=360f/deserializedNameData.names.Length;
            float StartAddress=0;
            float EndAddress=angleSize;
            foreach (string nam in deserializedNameData.names)
            {
                circlesList.Add(new CirclesCOLOUR { circleName = nam, startingAngle = StartAddress, endingAngle = EndAddress });
                StartAddress+=angleSize;
                EndAddress+=angleSize;
                
            }
            //int i=0;
            int numberOfElements = circlesList.Count;
            if(numberOfElements<=1){
                //spinButtonPressed=false;
            }
            int A=0;
            foreach (var circle in circlesList)
            {  
                if(A==numberOfElements-1)
                {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "white", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(A%5==0)
                {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "red", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
               else if(A%5==1)
                {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "blue", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(A%5==2)
                {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "green", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(A%5==3) 
                 {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "yellow", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(A%5==4) 
                 {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "purple", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
               
                A++;
            }
            CreateHollowCircle();
            CreateCircularSegment1(0f,360f,"red",313f,"");
            if(numberOfElements==1)
            {
                Canvas.SetActive(true);
            }
        }
        else
        {
            Debug.LogWarning("JSON file not found: " + filePath);
        }
    }
    void Update()
    {
        // if (Input.GetKeyDown(KeyCode.Space))
        // {
        //     totalAngleRotated=0;
        //     StartCoroutine(SpinWheel());
        // }
    }
    public void Revolve()
    {
        if(isSpinAllowed==true){
            isSpinAllowed=false;
        totalAngleRotated=0;
        spinButtonPressed=true;
        StartCoroutine(SpinWheel());
        ParticleSystem.SetActive(false);
        CanvasPanel.SetActive(false);
        }
    }
    private IEnumerator SpinWheel()
    {
        float rotationSpeed = maxRotationSpeed;
        float initialRotationSpeed = maxRotationSpeed;
        float targetRotationSpeed = 0f;
        float t = 0f;
        float duration = 11.0f;  

        Vector3 controlPoint1 = new Vector3(0.5f, 0f+3F, 0f);
        Vector3 controlPoint2 = new Vector3(0.75f, 0.25f, 0f);

        while (rotationSpeed > 0)
        {
            if(rotationSpeed<11)
            {
                ParticleSystem.SetActive(true);
                smallerCircle();
            }
            // Forward for anticlockwise
            transform.Rotate(Vector3.back, rotationSpeed * Time.deltaTime);
            //totalAngleRotated += rotationSpeed * Time.deltaTime;
            totalAngleRotated += rotationSpeed * Time.deltaTime;

            t += Time.deltaTime / duration;
            float t2 = t * t;
            float t3 = t2 * t;
            float oneMinusT = 1f - t;
            float oneMinusT2 = oneMinusT * oneMinusT;
            float oneMinusT3 = oneMinusT2 * oneMinusT;

            // Cubic Bezier interpolatiaon for rotationSpeed.
            rotationSpeed = initialRotationSpeed * oneMinusT3 + 3f * controlPoint1.x * t * oneMinusT2 +3f * controlPoint2.x * t2 * oneMinusT +
                            targetRotationSpeed * t3;

            yield return null;
        }
        //smallerCircle();
        isWinner();
    }
    //WORKEEEEE
    public void CreateCircularSegment(float startAngle, float endAngle, string borderColorName, float angle, string text)
    {
        GameObject segmentObject = new GameObject("CircularSegment");
        segmentObject.transform.SetParent(transform); // Set as child of the current GameObject

        MeshFilter meshFilter = segmentObject.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = segmentObject.AddComponent<MeshRenderer>();
        Mesh mesh = new Mesh();

        int verticesCount = numSegments + 2;
        Vector3[] vertices = new Vector3[verticesCount];
        int[] triangles = new int[numSegments * 3];

         vertices[0] =new Vector3(0f,3f,0f);
        //vertices[0] = Vector3.zero;

        float angleIncrement = (endAngle - startAngle) / numSegments;
        float currentAngle = startAngle;
        for (int i = 1; i < verticesCount; i++)
        {
            float x = Mathf.Sin(currentAngle * Mathf.Deg2Rad) * radius;
            float y = Mathf.Cos(currentAngle * Mathf.Deg2Rad) * radius;
            vertices[i] = new Vector3(x, y+3f, 0f);
            currentAngle += angleIncrement;
        }
        // Create line strip triangles for the borders
        for (int i = 0; i < numSegments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;
        }

         mesh.vertices = vertices;
        mesh.triangles = triangles;
        meshFilter.mesh = mesh;

        {
            Material redMaterial = Resources.Load<Material>(borderColorName);
            if (redMaterial != null)
            {
                Renderer renderer = GetComponent<Renderer>();
                renderer.material = redMaterial;
            }
            else
            {
                Debug.LogError("Failed to load the material from Resources.");
            }
             meshRenderer.material=redMaterial;
        }
        float middleAngle = (startAngle + endAngle) * 0.5f;

            // TextField
            {
                GameObject textObject = new GameObject("TextAlongAngle");
                textObject.transform.SetParent(segmentObject.transform); // Set as child of the segment GameObject
                textObject.transform.localScale = new Vector3(1f, 1f, 1f);

                TMP_Text textMesh = textObject.AddComponent<TextMeshPro>();
                textMesh.text = text;
                textMesh.fontSize = 4.5F;
                //textMesh.color = Color.black;
                textMesh.alignment = TextAlignmentOptions.Center;

                // Calculate position for the text along the middle angle of the segment
                float x = Mathf.Sin(middleAngle * Mathf.Deg2Rad) * (radius * 0.6f); // Adjust 0.6f to control the position of the text within the segment
                float y = Mathf.Cos(middleAngle * Mathf.Deg2Rad) * (radius * 0.6f);

                textObject.transform.localPosition = new Vector3(x, y+3F, 0f);
                Vector3 rotationVector = new Vector3(0f, 0f, angle);
                //textObject.transform.rotation = Quaternion.Euler(rotationVector);
                //textObject.transform.LookAt(Vector3.zero, Vector3.forward);
            
            }

    }
    public void CreateHollowCircle()
    {
        GameObject circleObject = new GameObject("CircularSegment");
        circleObject.transform.SetParent(transform);

        // Create the inner fill
        MeshFilter meshFilter = circleObject.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = circleObject.AddComponent<MeshRenderer>();
        Mesh mesh = new Mesh();

        int verticesCount = NumberOfSegments + 1;
        Vector3[] vertices = new Vector3[verticesCount];
        int[] triangles = new int[NumberOfSegments * 3];

        float angleIncrement = 360f / NumberOfSegments;
        float currentAngle = 0f;

        for (int i = 0; i < verticesCount; i++)
        {
            float x = Mathf.Sin(currentAngle * Mathf.Deg2Rad) * RADIUS;
            float y = Mathf.Cos(currentAngle * Mathf.Deg2Rad) * RADIUS;
            vertices[i] = new Vector3(x, y+3f, 0f);

            currentAngle += angleIncrement;
        }

        for (int i = 0; i < NumberOfSegments; i++)
        {
            triangles[i * 3] = 0; // Center vertex
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;

        }

        triangles[triangles.Length - 1] = 1; 

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        meshFilter.mesh = mesh;

        Material fillMaterial = new Material(Shader.Find("Sprites/Default"));
        fillMaterial.color = fillColor;
        meshRenderer.material = fillMaterial;

        // Create the boundaries using LineRenderer
        LineRenderer lineRenderer = circleObject.AddComponent<LineRenderer>();
        lineRenderer.positionCount = verticesCount;
        lineRenderer.useWorldSpace = false;
        lineRenderer.startWidth = boundaryThickness; // Adjust the boundary thickness here
        lineRenderer.endWidth = boundaryThickness; // Adjust the boundary thickness here

        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.material.color = borderColor;

        lineRenderer.loop = true;
        for (int i = 0; i < verticesCount; i++)
        {
            lineRenderer.SetPosition(i, vertices[i]);
        }
    }
    public void CreateCircularSegment1(float startAngle, float endAngle, string borderColorName, float angle, string text)
    {
        GameObject segmentObject = new GameObject("CircularSegment1");
        segmentObject.transform.SetParent(transform); // Set as child of the current GameObject

        MeshFilter meshFilter = segmentObject.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = segmentObject.AddComponent<MeshRenderer>();
        Mesh mesh = new Mesh();

        int verticesCount = numSegments + 2;
        Vector3[] vertices = new Vector3[verticesCount];
        int[] triangles = new int[numSegments * 3];

         vertices[0] =new Vector3(0f,3f,-0.1f);
        //vertices[0] = Vector3.zero;

        float angleIncrement = (endAngle - startAngle) / numSegments;
        float currentAngle = startAngle;
        for (int i = 1; i < verticesCount; i++)
        {
            float x = Mathf.Sin(currentAngle * Mathf.Deg2Rad) * RADIUS;
            float y = Mathf.Cos(currentAngle * Mathf.Deg2Rad) * RADIUS;
            vertices[i] = new Vector3(x, y+3f, 0f);
            currentAngle += angleIncrement;
        }
        // Create line strip triangles for the borders
        for (int i = 0; i < numSegments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;
        }

         mesh.vertices = vertices;
        mesh.triangles = triangles;
        meshFilter.mesh = mesh;

        {
            Material redMaterial = Resources.Load<Material>(borderColorName);
            if (redMaterial != null)
            {
                Renderer renderer = GetComponent<Renderer>();
                renderer.material = redMaterial;
            }
            else
            {
                Debug.LogError("Failed to load the material from Resources.");
            }
             meshRenderer.material=redMaterial;
        }
     
    }
    public void isWinner()
    {
        updatedNames.Clear();
        string Winner="";
        foreach (var circle in circlesList)
            {
               circle.startingAngle+=totalAngleRotated;
               circle.endingAngle+=totalAngleRotated;
               
               float divisor=360F;
               circle.startingAngle%=divisor;
               circle.endingAngle%=divisor;
               // Debug.Log($"Circle: {circle.circleName}, Starting Angle: {circle.startingAngle}, Ending Angle: {circle.endingAngle}");             
                if(circle.startingAngle<=90 && circle.endingAngle>90 || circle.endingAngle>=90 && circle.startingAngle>=270 && circle.startingAngle>circle.endingAngle)
                {
                    Debug.Log("Winner is ="+circle.circleName);
                    Winner=circle.circleName;
                    //Winner=circle.circleName+circle.startingAngle+" "+circle.endingAngle+ " ANGLeroated"+ totalAngleRotated;
                }
                else
                {
                    updatedNames.Add(circle.circleName);
                }
            }
            //smallerCircle();

            // float segments=updatedNames.Count+1;
            // float NetSegmentAngle=360f/(updatedNames.Count+1);
            // float NetAngleRotated=totalAngleRotated%360f;

            // float beginAngle=0f;
            // float lastAngle=NetSegmentAngle;
            // int flag=-1;
            // for(int l=0;l<segments;l++)
            // {
            //     beginAngle=NetSegmentAngle*l;
            //     lastAngle=beginAngle+NetSegmentAngle;

            //     beginAngle+=NetAngleRotated;
            //     lastAngle+=NetAngleRotated;

            //     beginAngle%=360f;
            //     lastAngle%=360f;

            //     if(beginAngle<=90 && lastAngle>90 || lastAngle>=90 && beginAngle>=270 && beginAngle>lastAngle)
            //     {
            //         flag=l;
            //         break;
            //     }
            // }
            // Debug.Log("flag="+flag);
            // DestroyCircularSegment();
            // if(flag==segments-1)
            //     {CreateCircularSegment1(0f,360f,"white",313f,"");}  
            // else if(flag==0)
            //     {CreateCircularSegment1(0f,360f,"red",313f,"");}  
            // else if(flag==1)
            //     {CreateCircularSegment1(0f,360f,"blue",313f,"");}  
            // else if(flag==2)
            //     {CreateCircularSegment1(0f,360f,"green",313f,"");}  
            // else if(flag==3)
            //     {CreateCircularSegment1(0f,360f,"yellow",313f,"");}  
            // else if(flag==4)
            //     {CreateCircularSegment1(0f,360f,"purple",313f,"");}   
            
            WinnerText.text=Winner;
            CanvasPanel.SetActive(true);
            WriteToJSON();
           
            StartCoroutine(WaitForOneSecond());  
    }
    public void smallerCircle()
    {
            float segments=circlesList.Count;
            float NetSegmentAngle=360f/segments;
            float NetAngleRotated=totalAngleRotated%360f;

            float beginAngle=0f;
            float lastAngle=NetSegmentAngle;
            int flag=-1;
            for(int l=0;l<segments;l++)
            {
                beginAngle=NetSegmentAngle*l;
                lastAngle=beginAngle+NetSegmentAngle;

                beginAngle+=NetAngleRotated;
                lastAngle+=NetAngleRotated;

                beginAngle%=360f;
                lastAngle%=360f;

                if(beginAngle<=90 && lastAngle>90 || lastAngle>=90 && beginAngle>=270 && beginAngle>lastAngle)
                {
                    flag=l;
                    break;
                }
            }
            Debug.Log("flag="+flag);
            DestroyCircularSegment();
            if(flag==segments-1)
                {CreateCircularSegment1(0f,360f,"white",313f,"");}  
            else if(flag==0)
                {CreateCircularSegment1(0f,360f,"red",313f,"");}  
            else if(flag==1)
                {CreateCircularSegment1(0f,360f,"blue",313f,"");}  
            else if(flag==2)
                {CreateCircularSegment1(0f,360f,"green",313f,"");}  
            else if(flag==3)
                {CreateCircularSegment1(0f,360f,"yellow",313f,"");}  
            else if(flag==4)
                {CreateCircularSegment1(0f,360f,"purple",313f,"");}   

    }
    private IEnumerator WaitForOneSecond()
    {
        yield return new WaitForSeconds(1.5f);
         isSpinAllowed=true;
        DestroyCreatedObjects();
        ClearSegments();
        BeginAgain();
        ParticleSystem.SetActive(false);
        CanvasPanel.SetActive(false);
    }
    static void PrintNames(List<string> names)
    {
        foreach (string name in names)
        {
          //  Debug.Log(name);
        }
    }
    public void ClearSegments()
    {
        // Destroy all child objects (segments and text)
        int childCount = transform.childCount;
        for (int i = childCount - 1; i >= 0; i--)
        {
            Transform child = transform.GetChild(i);
            Destroy(child.gameObject);
        }
    }
    public void DestroyCreatedObjects()
    {
        foreach (var circle in circlesList)
        {
            GameObject segmentObject = GameObject.Find(circle.circleName); // Assuming the circle name is unique
            if (segmentObject != null)
            {
                Destroy(segmentObject);
            }
        }
        circlesList.Clear();
    }
    public void DestroyCircularSegment()
    {
        Transform circularSegment = transform.Find("CircularSegment1"); // Find the created object
        if (circularSegment != null)
        {
            Destroy(circularSegment.gameObject); // Destroy the object
        }
        else
        {
            Debug.LogWarning("CircularSegment object not found.");
        }
    }
    public void  WriteToJSON()   
    {
        Names nameData1 = new Names();
        //if(updatedNames.Count==1){updatedNames.Clear();}
        nameData1.names = updatedNames.ToArray();
        string jsonString = JsonUtility.ToJson(nameData1);
        string filePath = Application.persistentDataPath + "/names.json";
       if (System.IO.File.Exists(filePath))
        {
           System.IO.File.Delete(filePath);
        }        
        filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, jsonString);

    }
    public void playAgain()
    {
        SceneManager.LoadScene("InputNames");  
    }
}
