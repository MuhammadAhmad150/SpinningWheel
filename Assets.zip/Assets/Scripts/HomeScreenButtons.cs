using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeScreenButtons : MonoBehaviour
{
    public void loadHomePage()
    {
        SceneManager.LoadScene("Home");
    }

    public void PlayButton()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void loadShoppingPage()
    {
        SceneManager.LoadScene("Shopping");
    }
}
